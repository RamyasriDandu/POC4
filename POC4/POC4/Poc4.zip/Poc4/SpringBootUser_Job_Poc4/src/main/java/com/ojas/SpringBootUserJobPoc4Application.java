package com.ojas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootUserJobPoc4Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootUserJobPoc4Application.class, args);
	}

}
